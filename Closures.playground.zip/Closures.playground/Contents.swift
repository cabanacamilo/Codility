func adition(numbers: [Int]) -> Int {
    var total = 0
    for number in numbers {
        total = number + total
    }
    return total
}

//print(adition(numbers: [1,2,3,4,5,6,7,8,9,10]))

let addClosure = { (numbers: [Int]) -> Int in
    var total = 0
    for number in numbers {
        total = number + total
    }
    return total
}

let add = addClosure([1,2,3,4,5,6,7,8,9,10])
//print(add)

struct person {
    var name: String
    var age: Int
    var address: String
    var email: String
}

var people = [
    person(name: "Minami", age: 28, address: "123 tokyo", email: "minami@email.com"),
    person(name: "Olga", age: 55, address: "321 colombia", email: "olga@email.com"),
    person(name: "Camilo", age: 27, address: "456 tokyo", email: "camilo@email.com"),
    person(name: "Test", age: 33, address: "123 test", email: "test@email.com")]

//sort

var sortedPeople = people.sorted(by: { (firstPerson, secondPerson) -> Bool in
    return firstPerson.age < secondPerson.age
})

//same but shorter version

var sortedPeopleShort = people.sorted { $0.age < $1.age}

//print(sortedPeopleShort)

//map

var numbers = [1,4,76,3,67,74,10,34]

var mapNumbers = numbers.map { (number) in
    return number + 2
}

var mapNumbersShort = numbers.map { $0 + 2 }

//filter

var numbersFilter = numbers.filter { (number) -> Bool in
    return number < 20
}

var numbersFilterShort = numbers.filter { $0 < 20 }

//print(numbersFilterShort)

// reduce

var numbersReduce = numbers.reduce(0) { (currentSum, number) -> Int in
    return currentSum + number
}

var numbersReduceShort = numbers.reduce(0, { $0 + $1 })

print(numbersReduceShort)
